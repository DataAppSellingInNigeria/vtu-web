// src/pages/dashboard/Wallet.jsx
export default function Wallet() {
    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Wallet</h1>
            <p className="text-gray-600">Check your balance, fund your wallet, and view transaction history here.</p>
        </div>
    );
}
