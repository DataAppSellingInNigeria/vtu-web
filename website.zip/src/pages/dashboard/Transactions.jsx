// src/pages/dashboard/Transactions.jsx
export default function Transactions() {
    return (
        <div>
            <h1 className="text-2xl font-bold mb-4">Transaction History</h1>
            <p className="text-gray-600">View all your airtime, data, and utility purchase logs here.</p>
        </div>
    );
}